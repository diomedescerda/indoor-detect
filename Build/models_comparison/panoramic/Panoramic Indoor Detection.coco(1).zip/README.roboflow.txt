
Panoramic Indoor Detection - vdataset panoramic-indoor-detection
==============================

This dataset was exported via roboflow.com on August 4, 2026 at 9:47 PM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 57 images.
Panoramic-Indoor-Detection are annotated in COCO format.

No pre-processing or augmentation was applied.
